package com.sv.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.sv.page.Page;
import com.thoughtworks.selenium.Wait.WaitTimedOutException;

public class TestPage {
	WebDriver driver;
	Page page;
	
	@BeforeClass
	public void startChrome(){
		System.setProperty("webdriver.chrome.driver","D:/Users/ADM-IG-HWDLAB1B/Desktop/chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://www.goibibo.com/flights/");
		page = PageFactory.initElements(driver, Page.class);
	}
	
	//For Firefox
	/*@BeforeClass
	  public void startFirefox(){
		driver= new FirefoxDriver();
		driver.get("https://www.goibibo.com/");
	}*/
	
	@Test (priority = 1) //Round Trip
	public void testMethod() throws Exception{
		
		
		File src1 = new File("./Configuration/myfile.property");
		FileInputStream fis1 = new FileInputStream(src1);
		
		//to read the property file create an object of properties class
		Properties pro = new Properties();
		
		// to load property file 
		pro.load(fis1);
		
		page.click(page.getXmlValue(pro.getProperty("roundPath")));
		
		page.sendValues(page.getXmlValue(pro.getProperty("fromData")),page.getXmlValue(pro.getProperty("fromPath")));
		
		page.sendValues(page.getXmlValue(pro.getProperty("toData")),page.getXmlValue(pro.getProperty("toPath")));
		
		page.click(page.getXmlValue(pro.getProperty("openCalanderPath")));
		
		page.click(page.getXmlValue(pro.getProperty("dateSelectorPath")));
		
		page.click(page.getXmlValue(pro.getProperty("returnDatePath")));
		
		page.click(page.getXmlValue(pro.getProperty("returnDateSelectionPath")));
	   
		page.click(page.getXmlValue(pro.getProperty("travellerXpath")));
	   
		page.click(page.getXmlValue(pro.getProperty("adultXPath")));
	   
		page.click(page.getXmlValue(pro.getProperty("childXPath")));
	   
		page.dropDown(page.getXmlValue(pro.getProperty("Class")), "B");
	   
		page.click(page.getXmlValue(pro.getProperty("PriceChange")));
	   
		page.click(page.getXmlValue(pro.getProperty("GetSetGo")));
	   
		page.click(page.getXmlValue(pro.getProperty("TicketBook")));
	}
	
	@Test (priority = 2)
	public void testOneWay() throws Exception{
		
		File src1 = new File("./Configuration/myfile.property");
		FileInputStream fis1 = new FileInputStream(src1);
		//to read the property file create an object of properties class
		Properties pro = new Properties();
		
		// to load property file 
		pro.load(fis1);
		
		driver.get("https://www.goibibo.com/flights/");
		
		page.click(page.getXmlValue(pro.getProperty("oneWayPath")));
		
		page.sendValues(page.getXmlValue(pro.getProperty("fromData")),page.getXmlValue(pro.getProperty("fromPath")));
		
		page.sendValues(page.getXmlValue(pro.getProperty("toData")),page.getXmlValue(pro.getProperty("toPath")));
		
		page.click(page.getXmlValue(pro.getProperty("openCalanderPath")));
		
		page.click(page.getXmlValue(pro.getProperty("dateSelectorPath")));

		page.click(page.getXmlValue(pro.getProperty("travellerXpath")));
		   
		page.click(page.getXmlValue(pro.getProperty("adultXPath")));
	   
		page.click(page.getXmlValue(pro.getProperty("childXPath")));
	   
		page.dropDown(page.getXmlValue(pro.getProperty("Class")), "B");
	   
		page.click(page.getXmlValue(pro.getProperty("PriceChange")));
	   
		page.click(page.getXmlValue(pro.getProperty("GetSetGo")));
	   
		page.click(page.getXmlValue(pro.getProperty("TicketBook2")));
	}
	
	@AfterClass
	public void Last() throws Exception
	{
		page.waitTime();
		driver.close();
	}
}