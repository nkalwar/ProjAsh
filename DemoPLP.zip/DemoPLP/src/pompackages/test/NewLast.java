package pompackages.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewLast {
	
	@Test
	public void TestConfig() throws IOException, InterruptedException, DocumentException
	{
		//to access property file
		File src= new File("D:/dataservlet3.0/DemoNG/Config/Working.xml");
		FileInputStream fis = new FileInputStream(src);
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
		//System.setProperty("webdriver.chrome.driver","D:/Users/ADM-IG-HWDLAB1B/Downloads/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
		
		driver.findElement(By.id(document.selectSingleNode("//form_detail/username").getText())).sendKeys("ashish");
	}

}
