package com.FireBuggies.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class VerifyReports {
	 public WebDriver driver;
	 public ExtentReports extent;
	 public ExtentTest test;
	 
	 @BeforeTest
	 public void openBrowser(){
		 extent=new ExtentReports("D:/Users/ADM-IG-HWDLAB1B/Desktop/FireBuggies/Config/TestResults.html", true);
		 test=extent.startTest("Verify Open Browser");
		 test.log(LogStatus.INFO, "Open browser test is instantiated");
		 System.setProperty("webdriver.chrome.driver","D:/Users/ADM-IG-HWDLAB1B/Desktop/chrome/chromedriver.exe");
			driver= new ChromeDriver();
			driver.manage().window().maximize();
			test.log(LogStatus.PASS, "Browser is opened and window is maximized");
			driver.get("https://www.goibibo.com/flights/");
			test.log(LogStatus.PASS, "Url gets opened");
			extent.endTest(test);
			extent.flush();
	 }
	 
  @Test
  public void roundTrip() {
	  
	  test=extent.startTest("Verify Round Trip");
	  String Actual="Flight Booking, cheap flight, lowest prices";
	  String expected=driver.getTitle();
	  if(expected.equals(Actual))
	  {
		  test.log(LogStatus.PASS, "Title is same");
		  System.out.println("True");
	  }
	  else
	  {
		  test.log(LogStatus.FAIL, "Title is not same");
		  System.out.println("False");
	  }
	  
  }
}
